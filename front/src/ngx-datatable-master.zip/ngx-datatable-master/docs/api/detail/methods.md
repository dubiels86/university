## Row Detail Methods

### `collapseAllRows()`

Collapse all row details when using row detail templates.

### `expandAllRows()`

Expand all row details when using row detail templates.

### `toggleExpandRow(row)`

Toggle expand/collapse a row detail when using row detail templates.
