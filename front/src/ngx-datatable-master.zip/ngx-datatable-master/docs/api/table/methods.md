## Table Methods

### `recalculate()`

Recalculate the grid sizes.
