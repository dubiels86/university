## Community

Below is a list of community contributions and projects that use the table.

- [ng2-inline-editor](https://github.com/Caballerog/ng2-inline-editor/tree/master/demos/angular2-data-table) - inline edit cell values with ng2-inline-editor and ngx-datatable projects.

If you have a project using the table and would love to share with the community, please reach out on
gh issues and we would love to add it to the growing list!
