export enum ClickType {
  single = 'single',
  double = 'double'
}
