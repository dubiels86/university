export enum ContextmenuType {
  header = 'header',
  body = 'body'
}
