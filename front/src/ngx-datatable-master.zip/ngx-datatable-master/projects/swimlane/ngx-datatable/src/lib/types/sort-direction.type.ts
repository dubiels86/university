export enum SortDirection {
  asc = 'asc',
  desc = 'desc'
}
