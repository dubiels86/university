export enum ColumnMode {
  standard = 'standard',
  flex = 'flex',
  force = 'force'
}
