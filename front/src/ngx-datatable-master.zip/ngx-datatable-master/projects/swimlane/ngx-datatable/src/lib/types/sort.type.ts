export enum SortType {
  single = 'single',
  multi = 'multi'
}
